import React from 'react';

const BacktestSummary = ({ summary }) => {
  if (!summary) return null;
  const items = [
    { label: 'PnL', value: Number(summary.pnl ?? 0).toFixed(2) },
    { label: 'Trades', value: String(summary.trades ?? 0) },
    { label: 'Win Rate', value: `${Number((summary.win_rate ?? 0) * 100).toFixed(1)}%` },
    { label: 'Avg R', value: Number(summary.avg_R ?? 0).toFixed(2) },
    { label: 'Max DD', value: Number(summary.max_drawdown ?? 0).toFixed(2) },
    { label: 'Sharpe', value: Number(summary.sharpe_lite ?? 0).toFixed(2) },
  ];
  return (
    <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', padding: '8px 0' }}>
      {items.map((it) => (
        <div key={it.label} style={{ background: '#0e1116', border: '1px solid #1f2630', padding: '6px 10px', borderRadius: 6 }}>
          <div style={{ fontSize: 12, color: '#9aa4b2' }}>{it.label}</div>
          <div style={{ fontWeight: 600, color: '#e0e5f2' }}>{it.value}</div>
        </div>
      ))}
    </div>
  );
};

export default BacktestSummary;


