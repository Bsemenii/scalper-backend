import React, { useState } from 'react';
import { runBacktest, getPaperConfig } from '../services/cryptoApi';
import BacktestSummary from './BacktestSummary';
import TradesPanel from './TradesPanel';

const BacktestPage = () => {
  const [form, setForm] = useState({
    symbol: 'BTCUSDT',
    start: '',
    end: '',
    interval: '1m',
    risk_usd: 25,
    atr_mult_stop: 1.2,
    take_r_mult: 1.6,
    max_hold_min: 45,
    min_signal_score: 0.1,
    min_bars_warmup: 250,
    allow_flip_close_open: false,
    debug: true,
  });
  const [result, setResult] = useState(null);
  const [busy, setBusy] = useState(false);
  const [presetBusy, setPresetBusy] = useState(false);

  const update = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const loadPreset = async () => {
    if (presetBusy) return;
    setPresetBusy(true);
    try {
      const cfg = await getPaperConfig(form.symbol || 'BTCUSDT');
      // cfg shape: { symbol, atr_mult_stop, take_r_mult, max_hold_min, min_signal_score, risk_usd }
      setForm((f) => ({
        ...f,
        symbol: cfg.symbol || f.symbol,
        risk_usd: Number(cfg.risk_usd ?? f.risk_usd),
        atr_mult_stop: Number(cfg.atr_mult_stop ?? f.atr_mult_stop),
        take_r_mult: Number(cfg.take_r_mult ?? f.take_r_mult),
        max_hold_min: Number(cfg.max_hold_min ?? f.max_hold_min),
        min_signal_score: Number(cfg.min_signal_score ?? f.min_signal_score),
      }));
    } catch (e) {
      console.error('Failed to load paper config', e);
    } finally {
      setPresetBusy(false);
    }
  };

  const submit = async (e) => {
    e.preventDefault();
    if (busy) return;
    setBusy(true);
    try {
      const now = new Date();
      const endIso = new Date(now.getTime()).toISOString().replace(/\.\d{3}Z$/, 'Z');
      const startIso = new Date(now.getTime() - 24 * 60 * 60 * 1000).toISOString().replace(/\.\d{3}Z$/, 'Z');
      const payload = {
        ...form,
        start: form.start && form.start.trim() ? form.start : startIso,
        end: form.end && form.end.trim() ? form.end : endIso,
      };
      const res = await runBacktest(payload);
      setResult(res);
    } catch (err) {
      console.error(err);
      setResult({ error: String(err) });
    } finally {
      setBusy(false);
    }
  };

  const diag = result?.diagnostics || null;
  const equity = result?.equity_curve || [];

  return (
    <div style={{ padding: 16 }}>
      <h2 style={{ color: '#e0e5f2', marginBottom: 12 }}>Backtest</h2>
      <form onSubmit={submit} style={{ display: 'grid', gridTemplateColumns: 'repeat(4, minmax(160px, 1fr))', gap: 12, alignItems: 'end' }}>
        <div>
          <label style={{ color: '#9aa4b2', display: 'block', marginBottom: 4 }}>Symbol</label>
          <input value={form.symbol} onChange={(e)=>update('symbol', e.target.value)} style={{ width: '100%' }} />
        </div>
        <div>
          <label style={{ color: '#9aa4b2', display: 'block', marginBottom: 4 }}>Start (ISO)</label>
          <input value={form.start} onChange={(e)=>update('start', e.target.value)} placeholder="2024-03-10T00:00:00Z" style={{ width: '100%' }} />
        </div>
        <div>
          <label style={{ color: '#9aa4b2', display: 'block', marginBottom: 4 }}>End (ISO)</label>
          <input value={form.end} onChange={(e)=>update('end', e.target.value)} placeholder="2024-03-12T00:00:00Z" style={{ width: '100%' }} />
        </div>
        <div>
          <label style={{ color: '#9aa4b2', display: 'block', marginBottom: 4 }}>Interval</label>
          <select value={form.interval} onChange={(e)=>update('interval', e.target.value)} style={{ width: '100%' }}>
            <option value="1m">1m</option>
            <option value="5m">5m</option>
            <option value="15m">15m</option>
          </select>
        </div>

        <div>
          <label style={{ color: '#9aa4b2', display: 'block', marginBottom: 4 }}>Risk USD</label>
          <input type="number" step="0.01" value={form.risk_usd} onChange={(e)=>update('risk_usd', Number(e.target.value))} style={{ width: '100%' }} />
        </div>
        <div>
          <label style={{ color: '#9aa4b2', display: 'block', marginBottom: 4 }}>ATR Mult (SL)</label>
          <input type="number" step="0.01" value={form.atr_mult_stop} onChange={(e)=>update('atr_mult_stop', Number(e.target.value))} style={{ width: '100%' }} />
        </div>
        <div>
          <label style={{ color: '#9aa4b2', display: 'block', marginBottom: 4 }}>Take R Mult</label>
          <input type="number" step="0.01" value={form.take_r_mult} onChange={(e)=>update('take_r_mult', Number(e.target.value))} style={{ width: '100%' }} />
        </div>
        <div>
          <label style={{ color: '#9aa4b2', display: 'block', marginBottom: 4 }}>Max Hold (min)</label>
          <input type="number" step="1" value={form.max_hold_min} onChange={(e)=>update('max_hold_min', Number(e.target.value))} style={{ width: '100%' }} />
        </div>

        <div>
          <label style={{ color: '#9aa4b2', display: 'block', marginBottom: 4 }}>Min Signal Score</label>
          <input type="number" step="0.01" value={form.min_signal_score} onChange={(e)=>update('min_signal_score', Number(e.target.value))} style={{ width: '100%' }} />
        </div>
        <div>
          <label style={{ color: '#9aa4b2', display: 'block', marginBottom: 4 }}>Warmup Bars</label>
          <input type="number" step="1" value={form.min_bars_warmup} onChange={(e)=>update('min_bars_warmup', Number(e.target.value))} style={{ width: '100%' }} />
        </div>
        <div>
          <label style={{ color: '#9aa4b2', display: 'block', marginBottom: 4 }}>Flip Close/Open</label>
          <input type="checkbox" checked={form.allow_flip_close_open} onChange={(e)=>update('allow_flip_close_open', e.target.checked)} />
        </div>
        <div>
          <label style={{ color: '#9aa4b2', display: 'block', marginBottom: 4 }}>Debug</label>
          <input type="checkbox" checked={form.debug} onChange={(e)=>update('debug', e.target.checked)} />
        </div>

        <div style={{ display: 'flex', gap: 8 }}>
          <button type="submit" disabled={busy} style={{ padding: '8px 12px' }}>{busy ? 'Running…' : 'Run Backtest'}</button>
          <button type="button" onClick={loadPreset} disabled={presetBusy} style={{ padding: '8px 12px' }}>{presetBusy ? 'Loading…' : 'Use current paper settings'}</button>
        </div>
      </form>

      {/* Compact diagnostics near the form */}
      {diag && (
        <div style={{ marginTop: 8, color: '#9aa4b2', fontSize: 13, display: 'flex', gap: 16, flexWrap: 'wrap' }}>
          <div>opened {diag.entry_opened ?? 0}</div>
          <div>blocked {(() => {
            const b = diag.blocked || {}; return (b.cooldown ?? 0) + (b.daily_cap ?? 0) + (b.has_open ?? 0) + (b.signal_below_thresh ?? 0) + (b.atr_nan ?? 0) + (b.size_zero ?? 0);
          })()}</div>
          <div>tp {diag.exits?.tp ?? 0}</div>
          <div>sl {diag.exits?.sl ?? 0}</div>
          <div>time {diag.exits?.time ?? 0}</div>
          <div>flip {diag.exits?.flip ?? 0}</div>
        </div>
      )}

      {result?.error && (
        <div style={{ marginTop: 12, padding: '8px 10px', border: '1px solid #5b2b36', background: '#2a0f15', color: '#f5c6cb', borderRadius: 6 }}>
          {String(result.error)}
        </div>
      )}

      {result?.summary && <BacktestSummary summary={result.summary} />}

      {/* Equity sparkline */}
      {equity.length > 0 && (
        <div style={{ marginTop: 8 }}>
          <div style={{ color: '#9aa4b2', marginBottom: 4 }}>Equity</div>
          <div style={{ height: 80, background: '#0e1116', border: '1px solid #1f2630', borderRadius: 6, overflow: 'hidden', position: 'relative' }}>
            <svg width="100%" height="100%" viewBox={`0 0 ${Math.max(1, equity.length - 1)} 100`} preserveAspectRatio="none">
              {(() => {
                const vals = equity.map(e => Number(e.equity || 0));
                const minV = Math.min(...vals);
                const maxV = Math.max(...vals);
                const range = Math.max(1, maxV - minV);
                const pts = vals.map((v, i) => `${i},${100 - ((v - minV) / range) * 100}`).join(' ');
                return <polyline fill="none" stroke="#2ecc71" strokeWidth="1" points={pts} />;
              })()}
            </svg>
          </div>
        </div>
      )}

      {diag && (
        <div style={{ marginTop: 12 }}>
          <div style={{ color: '#9aa4b2', marginBottom: 6 }}>Diagnostics</div>
          <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
            <div style={{ background: '#0e1116', border: '1px solid #1f2630', padding: 8, borderRadius: 6 }}>
              <div style={{ color: '#9aa4b2' }}>Ticks</div>
              <div style={{ color: '#e0e5f2' }}>{diag.ticks} (usable: {diag.usable_ticks})</div>
            </div>
            <div style={{ background: '#0e1116', border: '1px solid #1f2630', padding: 8, borderRadius: 6 }}>
              <div style={{ color: '#9aa4b2' }}>Signals</div>
              <div style={{ color: '#e0e5f2' }}>BUY {diag.signals?.buy ?? 0} · SELL {diag.signals?.sell ?? 0} · FLAT {diag.signals?.flat ?? 0}</div>
            </div>
            <div style={{ background: '#0e1116', border: '1px solid #1f2630', padding: 8, borderRadius: 6 }}>
              <div style={{ color: '#9aa4b2' }}>Entries</div>
              <div style={{ color: '#e0e5f2' }}>Attempts {diag.entry_attempts ?? 0} · Opened {diag.entry_opened ?? 0}</div>
            </div>
            <div style={{ background: '#0e1116', border: '1px solid #1f2630', padding: 8, borderRadius: 6 }}>
              <div style={{ color: '#9aa4b2' }}>Blocked</div>
              <div style={{ color: '#e0e5f2', fontSize: 13 }}>
                cooldown {diag.blocked?.cooldown ?? 0}, daily_cap {diag.blocked?.daily_cap ?? 0}, has_open {diag.blocked?.has_open ?? 0}, signal_below {diag.blocked?.signal_below_thresh ?? 0}, atr_nan {diag.blocked?.atr_nan ?? 0}, size_zero {diag.blocked?.size_zero ?? 0}
              </div>
            </div>
            <div style={{ background: '#0e1116', border: '1px solid #1f2630', padding: 8, borderRadius: 6 }}>
              <div style={{ color: '#9aa4b2' }}>Exits</div>
              <div style={{ color: '#e0e5f2' }}>TP {diag.exits?.tp ?? 0} · SL {diag.exits?.sl ?? 0} · FLIP {diag.exits?.flip ?? 0} · TIME {diag.exits?.time ?? 0}</div>
            </div>
          </div>
        </div>
      )}

      {Array.isArray(result?.trades) && result.trades.length > 0 && <TradesPanel trades={result.trades} />}
    </div>
  );
};

export default BacktestPage;


