import React, { useEffect, useMemo, useRef, useState } from 'react';
import { createChart } from 'lightweight-charts';
import chartsManager from '../services/chartsManager';

// Using chartsManager for data; backend REST fallback removed in favor of live cache

// --- Indicator helpers ---
function calculateEMA(values, period) {
  if (!values || values.length === 0) return [];
  const k = 2 / (period + 1);
  const ema = new Array(values.length);
  ema[0] = values[0];
  for (let i = 1; i < values.length; i++) {
    ema[i] = values[i] * k + ema[i - 1] * (1 - k);
  }
  return ema;
}

function calculateBollinger(values, period = 20, stdDev = 2) {
  const upper = new Array(values.length);
  const lower = new Array(values.length);
  const middle = new Array(values.length);
  for (let i = period - 1; i < values.length; i++) {
    const slice = values.slice(i - period + 1, i + 1);
    const mean = slice.reduce((s, v) => s + v, 0) / period;
    const variance = slice.reduce((s, v) => s + Math.pow(v - mean, 2), 0) / period;
    const sd = Math.sqrt(variance);
    middle[i] = mean;
    upper[i] = mean + sd * stdDev;
    lower[i] = mean - sd * stdDev;
  }
  return { upper, lower, middle };
}

function calculateRSI(closes, period = 14) {
  const rsi = new Array(closes.length);
  const gains = new Array(closes.length).fill(0);
  const losses = new Array(closes.length).fill(0);
  for (let i = 1; i < closes.length; i++) {
    const change = closes[i] - closes[i - 1];
    gains[i] = Math.max(0, change);
    losses[i] = Math.max(0, -change);
  }
  for (let i = period; i < closes.length; i++) {
    const avgGain = gains.slice(i - period + 1, i + 1).reduce((s, v) => s + v, 0) / period;
    const avgLoss = losses.slice(i - period + 1, i + 1).reduce((s, v) => s + v, 0) / period;
    if (avgLoss === 0) {
      rsi[i] = 100;
    } else {
      const rs = avgGain / avgLoss;
      rsi[i] = 100 - 100 / (1 + rs);
    }
  }
  return rsi;
}

function calculateMACD(closes, fast = 12, slow = 26, signal = 9) {
  const emaFast = calculateEMA(closes, fast);
  const emaSlow = calculateEMA(closes, slow);
  const macd = emaFast.map((v, i) => (v !== undefined && emaSlow[i] !== undefined ? v - emaSlow[i] : undefined));
  const macdFiltered = macd.filter(v => v !== undefined);
  const signalLine = calculateEMA(macdFiltered, signal);
  const histogram = new Array(macd.length);
  let j = 0;
  for (let i = 0; i < macd.length; i++) {
    if (macd[i] !== undefined && signalLine[j] !== undefined) {
      histogram[i] = macd[i] - signalLine[j];
      j++;
    }
  }
  return { macd, signal: signalLine, histogram };
}

function calculateVWAP(candles) {
  // Typical price * volume cumulative / cumulative volume
  let cumulativePV = 0;
  let cumulativeV = 0;
  const vwap = new Array(candles.length);
  for (let i = 0; i < candles.length; i++) {
    const tp = (candles[i].high + candles[i].low + candles[i].close) / 3;
    cumulativePV += tp * candles[i].volume;
    cumulativeV += candles[i].volume;
    vwap[i] = cumulativeV > 0 ? cumulativePV / cumulativeV : undefined;
  }
  return vwap;
}

const CandleChart = ({ timeframe = '1m', title, symbol = 'BTCUSDT' }) => {
  const chartContainerRef = useRef();
  const chartRef = useRef();
  const candleSeriesRef = useRef();
  const volumeSeriesRef = useRef();
  const ema9Ref = useRef();
  const ema21Ref = useRef();
  const ema50Ref = useRef();
  const bbUpperRef = useRef();
  const bbLowerRef = useRef();
  const vwapRef = useRef();
  const rsiRef = useRef();
  const macdRef = useRef();
  const macdSignalRef = useRef();
  const macdHistRef = useRef();
  const [candles, setCandles] = useState([]);
  const lastSizeRef = useRef({ width: 0, height: 0 });
  const isAutoFitRef = useRef(true);
  const isProgrammaticZoomRef = useRef(false);

  const abortRef = useRef(null);

  useEffect(() => {
    if (!chartContainerRef.current) return;
    const initialWidth = chartContainerRef.current.clientWidth;
    const initialHeight = chartContainerRef.current.clientHeight;
    lastSizeRef.current = { width: initialWidth, height: initialHeight };

    const chart = createChart(chartContainerRef.current, {
      width: initialWidth,
      height: initialHeight,
      layout: {
        background: { type: 'solid', color: '#131722' },
        textColor: '#d1d4dc',
        fontSize: 11,
        fontFamily: 'system-ui, -apple-system, sans-serif',
      },
      grid: {
        vertLines: { color: '#2a2e39', style: 0, visible: true },
        horzLines: { color: '#2a2e39', style: 0, visible: true },
      },
      crosshair: { mode: 1 },
      rightPriceScale: {
        borderColor: '#2a2e39',
        borderVisible: true,
        scaleMargins: { top: 0.02, bottom: 0.15 },
      },
      timeScale: {
        borderColor: '#2a2e39',
        borderVisible: true,
        timeVisible: true,
        secondsVisible: false,
        rightOffset: 5,
        barSpacing: 11,
        minBarSpacing: 2,
      },
      handleScroll: { mouseWheel: true, pressedMouseMove: true },
      handleScale: { axisPressedMouseMove: true, mouseWheel: true, pinch: true },
    });
    chartRef.current = chart;

    const candleSeries = chart.addCandlestickSeries({
      upColor: '#26a69a',
      downColor: '#ef5350',
      borderDownColor: '#ef5350',
      borderUpColor: '#26a69a',
      wickDownColor: '#ef5350',
      wickUpColor: '#26a69a',
      priceScaleId: 'right',
    });
    candleSeriesRef.current = candleSeries;

    const volumeSeries = chart.addHistogramSeries({
      color: '#26a69a',
      priceFormat: { type: 'volume' },
      priceScaleId: 'volume',
      scaleMargins: { top: 0.85, bottom: 0 },
    });
    volumeSeriesRef.current = volumeSeries;

    chart.priceScale('volume').applyOptions({
      scaleMargins: { top: 0.85, bottom: 0 },
      mode: 2,
      borderVisible: false,
    });

    // Indicator series on main pane
    ema9Ref.current = chart.addLineSeries({ color: '#2196f3', lineWidth: 1, title: 'EMA 9', priceScaleId: 'right' });
    ema21Ref.current = chart.addLineSeries({ color: '#ff9800', lineWidth: 1, title: 'EMA 21', priceScaleId: 'right' });
    ema50Ref.current = chart.addLineSeries({ color: '#9c27b0', lineWidth: 2, title: 'EMA 50', priceScaleId: 'right' });
    vwapRef.current = chart.addLineSeries({ color: '#00e676', lineWidth: 1, title: 'VWAP', priceScaleId: 'right' });
    bbUpperRef.current = chart.addLineSeries({ color: 'rgba(120,123,134,0.7)', lineWidth: 1, lineStyle: 2, title: 'BB Upper', priceScaleId: 'right' });
    bbLowerRef.current = chart.addLineSeries({ color: 'rgba(120,123,134,0.7)', lineWidth: 1, lineStyle: 2, title: 'BB Lower', priceScaleId: 'right' });

    // Secondary overlays for RSI and MACD
    rsiRef.current = chart.addLineSeries({ color: '#e91e63', lineWidth: 2, title: 'RSI', priceScaleId: 'rsi' });
    macdRef.current = chart.addLineSeries({ color: '#00bcd4', lineWidth: 2, title: 'MACD', priceScaleId: 'macd' });
    macdSignalRef.current = chart.addLineSeries({ color: '#ff5722', lineWidth: 1, title: 'Signal', priceScaleId: 'macd' });
    macdHistRef.current = chart.addHistogramSeries({ color: '#607d8b', title: 'MACD Hist', priceScaleId: 'macd' });
    chart.priceScale('rsi').applyOptions({ scaleMargins: { top: 0.85, bottom: 0 }, mode: 0, borderVisible: false });
    chart.priceScale('macd').applyOptions({ scaleMargins: { top: 0.90, bottom: 0.05 }, mode: 2, borderVisible: false });

    const applySizeIfChanged = () => {
      if (!chartContainerRef.current || !chart) return;
      const w = chartContainerRef.current.clientWidth;
      const h = chartContainerRef.current.clientHeight;
      if (w <= 0 || h <= 0) return;
      if (w === lastSizeRef.current.width && h === lastSizeRef.current.height) return;
      lastSizeRef.current = { width: w, height: h };
      chart.applyOptions({ width: w, height: h });
    };

    const handleResize = () => {
      applySizeIfChanged();
    };
    window.addEventListener('resize', handleResize);

    // Observe container resize to keep chart dimensions in sync
    let resizeObserver;
    if (window.ResizeObserver) {
      resizeObserver = new ResizeObserver(() => {
        applySizeIfChanged();
      });
      resizeObserver.observe(chartContainerRef.current);
    }

    // Detect user-initiated zoom/pan to disable auto-fit
    const timeScale = chart.timeScale();
    const onRangeChanged = () => {
      if (!isProgrammaticZoomRef.current) {
        isAutoFitRef.current = false;
      }
    };
    timeScale.subscribeVisibleTimeRangeChange(onRangeChanged);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (resizeObserver) {
        resizeObserver.disconnect();
      }
      if (timeScale && onRangeChanged) {
        timeScale.unsubscribeVisibleTimeRangeChange(onRangeChanged);
      }
      if (chart) chart.remove();
    };
  }, []);

  useEffect(() => {
    const unsubscribe = chartsManager.subscribe(
      symbol,
      timeframe,
      (payload) => {
        setCandles(payload.candles);
      },
      () => {}
    );

    return () => {
      if (typeof unsubscribe === 'function') unsubscribe();
    };
  }, [timeframe, symbol]);

  useEffect(() => {
    if (!candles.length || !candleSeriesRef.current || !volumeSeriesRef.current) return;
    const candleData = candles.map(c => ({ time: c.time, open: c.open, high: c.high, low: c.low, close: c.close }));
    const volumeData = candles.map(c => ({ time: c.time, value: c.volume, color: c.close >= c.open ? 'rgba(38,166,154,0.5)' : 'rgba(239,83,80,0.5)' }));

    candleSeriesRef.current.setData(candleData);
    volumeSeriesRef.current.setData(volumeData);

    // Indicators
    const closes = candles.map(c => c.close);
    const ema9 = calculateEMA(closes, 9).map((v, i) => v !== undefined ? { time: candles[i].time, value: v } : null).filter(Boolean);
    const ema21 = calculateEMA(closes, 21).map((v, i) => v !== undefined ? { time: candles[i].time, value: v } : null).filter(Boolean);
    const ema50 = calculateEMA(closes, 50).map((v, i) => v !== undefined ? { time: candles[i].time, value: v } : null).filter(Boolean);
    const vwap = calculateVWAP(candles).map((v, i) => v !== undefined ? { time: candles[i].time, value: v } : null).filter(Boolean);
    const bb = calculateBollinger(closes, 20, 2);
    const bbUpper = bb.upper.map((v, i) => v !== undefined ? { time: candles[i].time, value: v } : null).filter(Boolean);
    const bbLower = bb.lower.map((v, i) => v !== undefined ? { time: candles[i].time, value: v } : null).filter(Boolean);
    const rsi = calculateRSI(closes, 14).map((v, i) => v !== undefined ? { time: candles[i].time, value: v } : null).filter(Boolean);
    const macdData = calculateMACD(closes, 12, 26, 9);
    const macd = macdData.macd.map((v, i) => v !== undefined ? { time: candles[i].time, value: v } : null).filter(Boolean);
    // Align signal line across same times
    const signal = [];
    let idx = 0;
    for (let i = 0; i < candles.length; i++) {
      if (macdData.macd[i] !== undefined && macdData.signal[idx] !== undefined) {
        signal.push({ time: candles[i].time, value: macdData.signal[idx] });
        idx++;
      }
    }
    const hist = macdData.histogram.map((v, i) => (
      v !== undefined ? { time: candles[i].time, value: v, color: v >= 0 ? 'rgba(38,166,154,0.7)' : 'rgba(239,83,80,0.7)' } : null
    )).filter(Boolean);

    if (ema9Ref.current) ema9Ref.current.setData(ema9);
    if (ema21Ref.current) ema21Ref.current.setData(ema21);
    if (ema50Ref.current) ema50Ref.current.setData(ema50);
    if (vwapRef.current) vwapRef.current.setData(vwap);
    if (bbUpperRef.current) bbUpperRef.current.setData(bbUpper);
    if (bbLowerRef.current) bbLowerRef.current.setData(bbLower);
    if (rsiRef.current) rsiRef.current.setData(rsi);
    if (macdRef.current) macdRef.current.setData(macd);
    if (macdSignalRef.current) macdSignalRef.current.setData(signal);
    if (macdHistRef.current) macdHistRef.current.setData(hist);

    // Preserve current zoom/pan: do not auto-fit unless explicitly requested
    if (isAutoFitRef.current && chartRef.current) {
      chartRef.current.timeScale().fitContent();
    }
  }, [candles]);

  const zoomIn = () => {
    if (!chartRef.current) return;
    const ts = chartRef.current.timeScale();
    ts.setBarSpacing(Math.min(ts.barSpacing() + 2, 30));
    isAutoFitRef.current = false;
  };
  const zoomOut = () => {
    if (!chartRef.current) return;
    const ts = chartRef.current.timeScale();
    ts.setBarSpacing(Math.max(ts.barSpacing() - 2, 2));
    isAutoFitRef.current = false;
  };
  const resetView = () => {
    if (!chartRef.current) return;
    isAutoFitRef.current = true;
    isProgrammaticZoomRef.current = true;
    chartRef.current.timeScale().fitContent();
    // allow future user changes to override auto-fit again
    setTimeout(() => { isProgrammaticZoomRef.current = false; }, 0);
  };

  return (
    <div style={{ position: 'relative', width: '100%', height: '100%', minWidth: 0, minHeight: 0 }}>
      <div style={{ position: 'absolute', top: 6, left: 8, zIndex: 2, display: 'flex', gap: 6 }}>
        <span style={{ color: '#9aa4b2', fontSize: 11, padding: '4px 8px', background: '#0f1218', border: '1px solid #2a2e39', borderRadius: 4 }}>
          {title || `${symbol} ${timeframe}`}
        </span>
      </div>
      <div style={{ position: 'absolute', top: 6, right: 8, zIndex: 2, display: 'flex', gap: 6 }}>
        <button onClick={zoomIn} style={{ background: '#1b222d', color: '#d1d4dc', border: '1px solid #2a2e39', padding: '4px 8px', borderRadius: 4, cursor: 'pointer' }}>Zoom +</button>
        <button onClick={zoomOut} style={{ background: '#1b222d', color: '#d1d4dc', border: '1px solid #2a2e39', padding: '4px 8px', borderRadius: 4, cursor: 'pointer' }}>Zoom -</button>
        <button onClick={resetView} style={{ background: '#1b222d', color: '#d1d4dc', border: '1px solid #2a2e39', padding: '4px 8px', borderRadius: 4, cursor: 'pointer' }}>Reset</button>
      </div>
      <div ref={chartContainerRef} style={{ width: '100%', height: '100%', position: 'relative', background: '#131722', minWidth: 0, minHeight: 0 }} />
    </div>
  );
};

export default CandleChart;


