import React from 'react';
import './CryptoDashboard.css';

const BASE = '/api';
const j = async (resOrPromise) => {
  const res = await resOrPromise;
  if (!res.ok) throw new Error(await res.text());
  return res.json();
};

async function fetchTrades(symbol, limit = 150, period = 'today') {
  const url = `${BASE}/paper/trades?symbol=${encodeURIComponent(symbol)}&limit=${limit}&period=${period}`;
  return j(fetch(url));
}

const fmtNum = (v, d = 2) => {
  const n = Number(v);
  if (!Number.isFinite(n)) return '—';
  return n.toFixed(d);
};
const fmtQty = (v) => {
  const n = Number(v);
  if (!Number.isFinite(n)) return '—';
  if (n >= 1) return n.toFixed(4);
  if (n >= 0.01) return n.toFixed(6);
  return n.toFixed(8);
};
const fmtTs = (iso) => {
  if (!iso) return '—';
  try {
    const dt = new Date(iso);
    return dt.toLocaleString();
  } catch { return iso; }
};

export default function TradesPanel({ activeSymbol, since }) {
  const [rows, setRows] = React.useState([]);
  const [period, setPeriod] = React.useState('today'); // 'today' | 'all'
  const [busy, setBusy] = React.useState(false);

  React.useEffect(() => {
    let live = true;
    const poll = async () => {
      try {
        const data = await fetchTrades(activeSymbol, 150, period);
        if (live) setRows(Array.isArray(data) ? data : []);
      } catch { /* silent */ }
    };
    poll();
    const t = setInterval(poll, 2000);
    return () => { live = false; clearInterval(t); };
  }, [activeSymbol, period]);

  // lightweight totals for the panel header (net assumes realized_pnl includes fees; if not, subtract fees_paid)
  const realized = rows.reduce((s, r) => s + (Number(r.realized_pnl) || 0), 0);
  const feesPaid = rows.reduce((s, r) => s + (Number(r.fees_paid) || 0), 0);
  const wins = rows.filter(r => Number(r.realized_pnl) > 0).length;
  const count = rows.length;
  const winRate = count ? (wins / count) * 100 : 0;
  const avgPnL = count ? realized / count : 0;

  return (
    <div className="panel" style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      <div className="panel-header" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <span>Closed Trades — {activeSymbol}</span>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <span style={{ fontSize: 12, color: '#9aa4b2' }}>
            {period === 'all' ? 'All time' : 'Today'} · {count} trades ·
            {' '}PnL: <b style={{ color: realized >= 0 ? '#16a34a' : '#dc2626' }}>${fmtNum(realized, 2)}</b> ·
            {' '}Fees: <b style={{ color: '#dc2626' }}>${fmtNum(feesPaid, 2)}</b> ·
            {' '}Win rate: <b>{fmtNum(winRate, 1)}%</b> ·
            {' '}Avg: <b style={{ color: avgPnL >= 0 ? '#16a34a' : '#dc2626' }}>${fmtNum(avgPnL, 2)}</b>
          </span>
          <select
            value={period}
            onChange={(e) => setPeriod(e.target.value)}
            style={{ background: '#0f1720', color: '#e6edf3', border: '1px solid #2b3a47', borderRadius: 4, padding: '2px 6px' }}
          >
            <option value="today">Today</option>
            <option value="all">All</option>
          </select>
        </div>
      </div>

      <div className="panel-body" style={{ overflow: 'auto' }}>
        {rows.length === 0 ? (
          <div className="empty">No closed trades</div>
        ) : (
          <div className="table-wrap">
            <table className="positions-table">
              <thead>
                <tr>
                  <th style={{ minWidth: 88 }}>Time (Close)</th>
                  <th>Side</th>
                  <th>Qty</th>
                  <th>Entry</th>
                  <th>Exit</th>
                  <th>Net PnL</th>
                  <th>Fees</th>
                  <th>Dur (s)</th>
                  <th>Reason</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r, i) => {
                  const pnl = Number(r.realized_pnl) || 0;
                  const fees = Number(r.fees_paid) || 0;
                  return (
                    <tr key={i}>
                      <td>{fmtTs(r.closed_at)}</td>
                      <td className={(r.side === 'long') ? 'pos' : 'neg'} style={{ textTransform: 'capitalize' }}>{r.side}</td>
                      <td>{fmtQty(r.qty)}</td>
                      <td>{fmtNum(r.entry_price, 2)}</td>
                      <td>{fmtNum(r.exit_price, 2)}</td>
                      <td className={pnl >= 0 ? 'pos' : 'neg'}>${fmtNum(pnl, 2)}</td>
                      <td className="neg">${fmtNum(fees, 2)}</td>
                      <td>{r.duration_seconds ?? '—'}</td>
                      <td><span style={{ fontSize: 12, color: '#9aa4b2' }}>{(r.reason || '').replace(/_/g, ' ') || '—'}</span></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
