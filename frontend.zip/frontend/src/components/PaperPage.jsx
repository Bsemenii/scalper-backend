import React from 'react';
import SummaryPanel from './SummaryPanel';
import TradesPanel from './TradesPanel';
import './CryptoDashboard.css';
import { paperStart, paperStop, getPaperStatus } from '../services/cryptoApi';

const PaperPage = () => {
  const [symbol, setSymbol] = React.useState('BTCUSDT');
  const [isBusy, setIsBusy] = React.useState(false);
  const [isPaperRunning, setIsPaperRunning] = React.useState(false);

  // Load initial running status for current symbol
  React.useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const status = await getPaperStatus();
        if (!mounted) return;
        const enabled = !!(status && status[symbol] && status[symbol].enabled);
        setIsPaperRunning(enabled);
      } catch (e) {
        // leave default false on error
      }
    })();
    return () => { mounted = false; };
  }, [symbol]);

  const handleTogglePaper = async () => {
    if (isBusy) return;
    setIsBusy(true);
    try {
      const res = isPaperRunning ? await paperStop(symbol) : await paperStart(symbol);
      setIsPaperRunning(!!(res && res.running)); // trust backend truth
    } catch (e) {
      console.error(e);
    } finally {
      setIsBusy(false);
    }
  };

  return (
    <div className="crypto-dashboard">
      <div className="dashboard-header">
        <div className="symbol-tabs">
          <span className={`tab ${symbol === 'BTCUSDT' ? 'active' : ''}`} onClick={() => setSymbol('BTCUSDT')}>BTCUSDT</span>
          <span className={`tab ${symbol === 'ETHUSDT' ? 'active' : ''}`} onClick={() => setSymbol('ETHUSDT')} style={{ marginLeft: 8 }}>ETHUSDT</span>
          <span className={`tab ${symbol === 'SOLUSDT' ? 'active' : ''}`} onClick={() => setSymbol('SOLUSDT')} style={{ marginLeft: 8 }}>SOLUSDT</span>
        </div>
        <div className="trade-controls">
          <button 
            className={`trade-btn ${isPaperRunning ? 'stop' : ''}`} 
            onClick={handleTogglePaper}
            disabled={isBusy}
          >
            {isPaperRunning ? `Paper: Running (${symbol})` : `Paper: Stopped (${symbol})`}
          </button>
        </div>
      </div>
      <div className="dash" style={{ gridTemplateColumns: 'minmax(0, 1fr) 440px' }}>
        <div className="dash-left" style={{ display: 'block', padding: 8 }}>
          <SummaryPanel />
        </div>
        <div className="dash-right" style={{ width: 440, minWidth: 440 }}>
          <TradesPanel activeSymbol={symbol} since={'now'} />
        </div>
      </div>
    </div>
  );
};

export default PaperPage;


