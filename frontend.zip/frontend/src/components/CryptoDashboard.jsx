import React, { useEffect, useState, useRef } from "react";
import { paperStart, paperStop, getRuntimeStatus } from "../services/cryptoApi";
import CandleChart from "./CandleChart";
import OrderBook from "./OrderBook";
import TradeTape from "./TradeTape";
import "./CryptoDashboard.css";

const CryptoDashboard = () => {
  const [ticker, setTicker] = useState({});
  const [symbol, setSymbol] = useState('BTCUSDT');
  const [runtime, setRuntime] = useState({ running: false, last_loop_ms_ago: null, paper_enabled: false });
  const [isBusy, setIsBusy] = useState(false);
  const wsRef = useRef(null);
  const reconnectTimerRef = useRef(null);
  const connectionIdRef = useRef(0);
  const currentSymbolRef = useRef('BTCUSDT');
  const paperSeenRef = useRef(new Map()); // id -> closed boolean

  useEffect(() => {
    // Reset ticker UI immediately on symbol change
    setTicker({});
    currentSymbolRef.current = symbol;
    const myConnectionId = ++connectionIdRef.current;
    let shouldReconnect = true;
    
    const connectCombinedStream = () => {
      // Use combined stream for better accuracy and lower latency
      // markPrice@1s gives the most accurate current price used by Binance
      const s = symbol.toLowerCase();
      const streams = [
        `${s}@ticker`,           // 24hr ticker data
        `${s}@aggTrade`,         // Individual trades for instant updates
        `${s}@markPrice@1s`      // Mark price - most accurate for futures (updates every second)
      ];
      
      const wsUrl = `wss://fstream.binance.com/stream?streams=${streams.join('/')}`;
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;
      
      ws.onopen = () => {
        console.log('✅ Combined WebSocket connected - Ultra-accurate real-time data active');
      };

      ws.onmessage = (event) => {
        try {
          const message = JSON.parse(event.data);
          const data = message.data;
          if (myConnectionId !== connectionIdRef.current) return; // stale connection
          if (data && data.s && data.s.toUpperCase() !== currentSymbolRef.current.toUpperCase()) return; // different symbol
          
          if (data.e === '24hrTicker') {
            // Update complete ticker data - but don't overwrite the latest price if we have a more recent one
            setTicker(prevTicker => ({
              ...prevTicker,
              // Do not override lastPrice here to avoid flicker; markPrice will drive lastPrice
              priceChangePercent: data.P,   // Price change percent
              priceChange: data.p,          // Price change
              volume: data.v,               // Base asset volume (BTC)
              quoteVolume: data.q,          // Quote asset volume (USDT) - this is what Binance web shows
              openPrice: data.o,            // Open price
              highPrice: data.h,            // High price
              lowPrice: data.l,             // Low price
              symbol: data.s                // Symbol
            }));
            console.log(`📊 Ticker update: Volume: ${parseFloat(data.v).toFixed(2)} BTC, Quote: ${parseFloat(data.q).toFixed(0)} USDT`);
          } else if (data.e === 'aggTrade') {
            // We intentionally do not set lastPrice from trades to prevent flicker vs mark price
            // Could store last trade price if needed in the future
            // console.log(`⚡ Trade update: $${parseFloat(data.p).toFixed(2)}`);
          } else if (data.e === 'markPriceUpdate') {
            // Mark price is the most accurate price used by Binance for futures
            // This is what you see on Binance web interface
            setTicker(prevTicker => ({
              ...prevTicker,
              lastPrice: data.p,  // Mark price - most accurate
              markPrice: data.p,   // Store mark price separately
              symbol: data.s || currentSymbolRef.current
            }));
            console.log(`🎯 Mark price update: $${parseFloat(data.p).toFixed(2)} (most accurate)`);
          }
        } catch (error) {
          console.error('Error parsing WebSocket data:', error);
        }
      };

      ws.onerror = (error) => {
        console.error('❌ Combined WebSocket error:', error);
      };

      ws.onclose = () => {
        console.log('🔌 Combined WebSocket closed - attempting reconnect...');
        if (shouldReconnect && !reconnectTimerRef.current) {
          reconnectTimerRef.current = setTimeout(() => {
            reconnectTimerRef.current = null;
            if (myConnectionId === connectionIdRef.current) {
              connectCombinedStream();
            }
          }, 2000); // Faster reconnect
        }
      };
    };

    // Initial connection
    connectCombinedStream();

    // Cleanup function
    return () => {
      shouldReconnect = false;
      if (reconnectTimerRef.current) {
        clearTimeout(reconnectTimerRef.current);
        reconnectTimerRef.current = null;
      }
      if (wsRef.current) {
        try { wsRef.current.close(); } catch {}
        wsRef.current = null;
      }
    };
  }, [symbol]);

  const formatPrice = (price) => {
    return parseFloat(price).toFixed(2);
  };

  const formatVolume = (volume) => {
    const num = parseFloat(volume);
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'K';
    }
    return num.toFixed(0);
  };

  const getPriceChangeClass = (priceChangePercent) => {
    const change = parseFloat(priceChangePercent || 0);
    return change >= 0 ? 'positive' : 'negative';
  };

  const formatPriceChangePercent = (priceChangePercent) => {
    const change = parseFloat(priceChangePercent || 0);
    const sign = change >= 0 ? '+' : '';
    return `${sign}${change.toFixed(2)}%`;
  };

  const handleStart = async () => {
    if (isBusy) return;
    setIsBusy(true);
    try {
      const res = await paperStart(symbol);
      try {
        const items = await getRuntimeStatus();
        const item = Array.isArray(items) ? items.find((i) => (i.symbol || '').toUpperCase() === symbol.toUpperCase()) : null;
        if (item && item.executor) {
          setRuntime({
            running: !!item.executor.running,
            last_loop_ms_ago: item.executor.last_loop_ms_ago ?? null,
            paper_enabled: !!item.executor.paper_enabled
          });
        }
      } catch {}
      return res;
    } catch (e) {
      console.error(e);
    } finally {
      setIsBusy(false);
    }
  };

  const handleStop = async () => {
    if (isBusy) return;
    setIsBusy(true);
    try {
      const res = await paperStop(symbol);
      try {
        const items = await getRuntimeStatus();
        const item = Array.isArray(items) ? items.find((i) => (i.symbol || '').toUpperCase() === symbol.toUpperCase()) : null;
        if (item && item.executor) {
          setRuntime({
            running: !!item.executor.running,
            last_loop_ms_ago: item.executor.last_loop_ms_ago ?? null,
            paper_enabled: !!item.executor.paper_enabled
          });
        }
      } catch {}
      return res;
    } catch (e) {
      console.error(e);
    } finally {
      setIsBusy(false);
    }
  };

  // Paper controls moved to Paper page

  // Paper trading removed

  // Heartbeat: poll runtime/status every 2s
  useEffect(() => {
    let cancelled = false;
    const poll = async () => {
      try {
        const items = await getRuntimeStatus();
        if (cancelled) return;
        const item = Array.isArray(items) ? items.find((i) => (i.symbol || '').toUpperCase() === symbol.toUpperCase()) : null;
        if (item && item.executor) {
          setRuntime({
            running: !!item.executor.running,
            last_loop_ms_ago: item.executor.last_loop_ms_ago ?? null,
            paper_enabled: !!item.executor.paper_enabled
          });
        }
      } catch {
        if (!cancelled) setRuntime((prev) => ({ ...prev, running: false }));
      }
    };
    poll();
    const interval = setInterval(poll, 2000);
    return () => { cancelled = true; clearInterval(interval); };
  }, [symbol]);

  // Paper trades section removed

  return (
    <div className="crypto-dashboard">
      {/* Header */}
      <div className="dashboard-header">
        <div className="symbol-tabs">
          <span 
            className={`tab ${symbol === 'BTCUSDT' ? 'active' : ''}`}
            onClick={() => setSymbol('BTCUSDT')}
          >
            BTCUSDT
          </span>
          <span 
            className={`tab ${symbol === 'ETHUSDT' ? 'active' : ''}`}
            onClick={() => setSymbol('ETHUSDT')}
            style={{ marginLeft: 8 }}
          >
            ETHUSDT
          </span>
          <span 
            className={`tab ${symbol === 'SOLUSDT' ? 'active' : ''}`}
            onClick={() => setSymbol('SOLUSDT')}
            style={{ marginLeft: 8 }}
          >
            SOLUSDT
          </span>
        </div>
        <div className="ticker-info">
          <div className="current-price">
            <span className="price">{formatPrice(ticker.lastPrice || "Loading...")}</span>
            <span className={`price-change ${getPriceChangeClass(ticker.priceChangePercent)}`}>
              {formatPriceChangePercent(ticker.priceChangePercent) || 'Loading...'}
            </span>
          </div>
          <div className="trade-controls">
            <div className="heartbeat-badge" title={runtime.last_loop_ms_ago != null ? `last loop ${runtime.last_loop_ms_ago} ms ago` : 'no heartbeat'}>
              <span className={`dot ${runtime.running ? 'ok' : 'off'}`}></span>
              <span className="hb-text">{runtime.running ? 'running' : 'stopped'}{runtime.last_loop_ms_ago != null ? ` · ${runtime.last_loop_ms_ago}ms` : ''}</span>
            </div>
            <button className={`trade-btn ${(runtime.paper_enabled || isBusy) ? 'disabled' : ''}`} onClick={handleStart} disabled={!!runtime.paper_enabled || isBusy}>{isBusy ? 'Working…' : 'Start Paper'}</button>
            <button className={`trade-btn stop ${(!runtime.paper_enabled || isBusy) ? 'disabled' : ''}`} onClick={handleStop} disabled={!runtime.paper_enabled || isBusy}>{isBusy ? 'Working…' : 'Stop Paper'}</button>
          </div>
        </div>
      </div>

      {/* Main Content - Two column grid */}
      <div className="dash">
        <div className="dash-left">
          <div className="chart-slot"><CandleChart timeframe="1m" title={`${symbol} 1m`} symbol={symbol} /></div>
          <div className="chart-slot"><CandleChart timeframe="5m" title={`${symbol} 5m`} symbol={symbol} /></div>
          <div className="chart-slot"><CandleChart timeframe="15m" title={`${symbol} 15m`} symbol={symbol} /></div>
        </div>
        <div className="dash-right">
          <div className="advanced-orderbook-container">
            <OrderBook symbol={symbol} />
          </div>
          <div className="trade-tape-container">
            <TradeTape symbol={symbol} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default CryptoDashboard;