import React, { useEffect, useRef, useState } from 'react';
import { getPaperSummary, getOpenPositions, getPaperTrades, getPaperStatus, getPaperConfig, setPaperConfig, getRuntimeStatus, resetMetrics, getMetricsState } from '../services/cryptoApi';

const num = (v, d = 2) => {
  const n = parseFloat(v ?? 0);
  if (!isFinite(n)) return '—';
  return n.toFixed(d);
};

const pct = (v) => {
  const n = parseFloat(v ?? 0) * 100;
  if (!isFinite(n)) return '—';
  return `${n.toFixed(1)}%`;
};

const SummaryPanel = () => {
  const [data, setData] = useState({
    pnl_today: 0,
    equity_today_usd: 0,
    open_upnl_usd: 0,
    fees_today_usd: 0,
    funding_today_usd: 0,
    trades_closed: 0,
    win_rate_closed: 0,
    avg_R_today: 0,
    max_dd_today: 0,
    open_positions: [],
    now: ''
  });
  const [error, setError] = useState(null);
  const [autoExits, setAutoExits] = useState({ enabled: false, max_hold_min: null });
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [symbol, setSymbol] = useState('BTCUSDT');
  const [cfg, setCfg] = useState({ atr_mult_stop: 1.5, take_r_mult: 2.0, max_hold_min: 30, min_signal_score: 0.0, risk_usd: 25 });
  const [toast, setToast] = useState(null);

  useEffect(() => {
    let mounted = true;
    let timer;

    const poll = async () => {
      try {
        const res = await getPaperSummary();
        if (!mounted) return;
        // Preserve open_positions from fast path to avoid flicker
        setData((prev) => ({ ...prev, ...res, open_positions: prev.open_positions }));
        setError(null);
      } catch (e) {
        if (!mounted) return;
        setError('Failed to load summary');
      }
    };

    poll();
    timer = setInterval(poll, 5000);
    return () => {
      mounted = false;
      if (timer) clearInterval(timer);
    };
  }, []);

  // Baseline state loader
  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const s = await getMetricsState();
        if (!mounted) return;
        setData((prev) => ({ ...prev, baseline_ts: s?.baseline_ts }));
      } catch {}
    })();
    return () => { mounted = false; };
  }, []);

  // Paper status polling for Auto exits badge
  useEffect(() => {
    let mounted = true;
    let timer;
    const pollStatus = async () => {
      try {
        const status = await getPaperStatus();
        if (!mounted) return;
        // status is a map: { BTCUSDT: { enabled, open_count, max_hold_min }, ... }
        let enabledAny = false;
        let holdMin = null;
        if (status && typeof status === 'object') {
          for (const k of Object.keys(status)) {
            const v = status[k];
            if (v && v.enabled) {
              enabledAny = true;
              if (v.max_hold_min != null && Number.isFinite(Number(v.max_hold_min))) {
                holdMin = Number(v.max_hold_min);
                break;
              }
            }
          }
        }
        setAutoExits({ enabled: enabledAny, max_hold_min: holdMin });
      } catch {}
    };
    pollStatus();
    timer = setInterval(pollStatus, 5000);
    return () => { mounted = false; if (timer) clearInterval(timer); };
  }, []);

  // In-memory anti-blink cache for open positions
  const openMapRef = useRef(new Map()); // id -> { item, lastSeenMs, staleSinceMs, stableKey }
  const lastRenderedRef = useRef(0);

  const nowMs = () => Date.now();
  const toNum = (v) => {
    const n = Number(v);
    return Number.isFinite(n) ? n : null;
  };
  const getId = (p) => p?.id ?? p?.position_id ?? p?.trade_id ?? p?.uid ?? null;
  const getMemId = (p) => p?.mem_id ?? p?.memory_id ?? null;
  const createSyntheticId = (p) => {
    const s = String(p?.symbol || '').toUpperCase();
    const side = String(p?.side || '').toLowerCase();
    const e = p?.entry_price ?? p?.entry ?? 0;
    const q = p?.qty ?? p?.quantity ?? 0;
    return `mem:${s}:${side}:${e}:${q}`;
  };
  const getSource = (idLike) => {
    if (!idLike) return 'unknown';
    if (typeof idLike === 'string' && idLike.startsWith('mem:')) return 'memory';
    if (/^\d+$/.test(String(idLike))) return 'db';
    return 'memory';
  };
  const nearlyEqual = (a, b, eps = 1e-6) => {
    const na = toNum(a); const nb = toNum(b);
    if (na == null || nb == null) return false;
    return Math.abs(na - nb) <= eps * Math.max(1, Math.abs(na), Math.abs(nb));
  };

  const recomputeDisplay = () => {
    const list = Array.from(openMapRef.current.values()).map((v) => v.item);
    list.sort((a, b) => String(a.symbol || '').localeCompare(String(b.symbol || '')) || String(a.stableKey).localeCompare(String(b.stableKey)));
    setData((prev) => ({ ...prev, open_positions: list }));
    lastRenderedRef.current = nowMs();
  };

  // Fast-path: poll open positions every ~2s and merge into display
  useEffect(() => {
    let mounted = true;
    let timer;

    const markStaleAndEvict = () => {
      const now = nowMs();
      let changed = false;
      for (const [key, rec] of openMapRef.current) {
        if (!rec.item.stale) {
          rec.item.stale = true;
          rec.staleSinceMs = now;
          changed = true;
        } else if (rec.staleSinceMs && now - rec.staleSinceMs > 10000) {
          openMapRef.current.delete(key);
          changed = true;
        }
      }
      if (changed) recomputeDisplay();
    };

    const pollPositions = async () => {
      try {
        const res = await getOpenPositions();
        if (!mounted) return;
        const arr = Array.isArray(res) ? res : [];
        const seen = new Set();
        const now = nowMs();

        if (arr.length === 0) {
          // Soft-stale: do not clear immediately
          markStaleAndEvict();
          return;
        }

        let changed = false;
        for (const p of arr) {
          let id = getId(p) ?? getMemId(p) ?? createSyntheticId(p);
          const memId = typeof id === 'string' && id.startsWith('mem:') ? id : (getMemId(p) || null);
          const src = getSource(id ?? memId);
          const itemCandidate = {
            id: id ?? memId,
            symbol: p.symbol,
            side: p.side,
            entry_price: p.entry_price,
            qty: p.qty,
            stop_price: p.stop_price ?? null,
            take_price: p.take_price ?? null,
            upnl_estimate: p.unrealized_pnl_est ?? p.upnl_estimate ?? null,
            source: src,
            stale: false,
            opened_at: p.opened_at || p.entry_time,
          };

          // Attempt mem -> db id swap matching
          if (id && /^\d+$/.test(String(id))) {
            // New DB id; see if we have a matching mem record
            let swapped = false;
            for (const [k, rec] of openMapRef.current) {
              if (typeof k === 'string' && k.startsWith('mem:')) {
                const it = rec.item;
                if (
                  (String(it.symbol || '').toUpperCase() === String(p.symbol || '').toUpperCase()) &&
                  (String(it.side || '').toLowerCase() === String(p.side || '').toLowerCase()) &&
                  (nearlyEqual(it.entry_price, p.entry_price, 1e-4)) &&
                  (nearlyEqual(it.qty, p.qty, 1e-6))
                ) {
                  // Move record under new DB id, preserve stableKey and reference
                  openMapRef.current.delete(k);
                  it.id = id;
                  it.source = 'merged';
                  it.stale = false;
                  rec.lastSeenMs = now;
                  rec.staleSinceMs = undefined;
                  // Keep existing stableKey; use map under new id
                  openMapRef.current.set(String(id), rec);
                  seen.add(String(id));
                  changed = true;
                  swapped = true;
                  break;
                }
              }
            }
            if (swapped) continue;
          }

          const key = String(itemCandidate.id);
          seen.add(key);
          const existing = openMapRef.current.get(key);
          if (existing) {
            const it = existing.item;
            it.symbol = itemCandidate.symbol;
            it.side = itemCandidate.side;
            it.entry_price = itemCandidate.entry_price;
            it.qty = itemCandidate.qty;
            it.upnl_estimate = itemCandidate.upnl_estimate;
            // If previously memory and now db, mark merged
            if (it.source !== itemCandidate.source && (it.source === 'memory' || itemCandidate.source === 'db')) {
              it.source = 'merged';
            } else {
              it.source = itemCandidate.source;
            }
            it.stale = false;
            existing.lastSeenMs = now;
            existing.staleSinceMs = undefined;
            changed = true;
          } else {
            const stableKey = String(itemCandidate.id);
            const rec = { item: { ...itemCandidate, stableKey }, lastSeenMs: now, staleSinceMs: undefined, stableKey };
            openMapRef.current.set(key, rec);
            changed = true;
          }
        }

        // Mark unseen as stale
        for (const [key, rec] of openMapRef.current) {
          if (!seen.has(String(key))) {
            if (!rec.item.stale) {
              rec.item.stale = true;
              rec.staleSinceMs = now;
              changed = true;
            } else if (rec.staleSinceMs && now - rec.staleSinceMs > 10000) {
              openMapRef.current.delete(key);
              changed = true;
            }
          }
        }

        if (changed) recomputeDisplay();
      } catch (e) {
        // ignore, summary poll will still refresh periodically
      }
    };

    pollPositions();
    timer = setInterval(pollPositions, 2000);
    return () => {
      mounted = false;
      if (timer) clearInterval(timer);
    };
  }, []);

  // Runtime status polling for recent block reasons -> toast
  useEffect(() => {
    let mounted = true;
    let timer;
    const pollRuntime = async () => {
      try {
        const items = await getRuntimeStatus();
        if (!mounted) return;
        if (Array.isArray(items)) {
          // Aggregate most recent block across symbols
          let best = null;
          for (const it of items) {
            const rb = it?.executor?.recent_block;
            if (rb && typeof rb === 'object') {
              if (!best || (rb.ts > best.ts)) best = { ...rb, symbol: it.symbol };
            }
          }
          if (best) {
            const label = String(best.reason || '').replace(/_/g, ' ');
            setToast({ id: `${best.symbol}:${best.ts}`, text: `Blocked: ${label}`, ts: best.ts });
            // Auto-dismiss after 4s
            setTimeout(() => {
              setToast((prev) => (prev && prev.id === `${best.symbol}:${best.ts}` ? null : prev));
            }, 4000);
          }
        }
      } catch {}
    };
    pollRuntime();
    timer = setInterval(pollRuntime, 1500);
    return () => { mounted = false; if (timer) clearInterval(timer); };
  }, []);

  // Load persisted settings on mount and hydrate server
  useEffect(() => {
    try {
      const s = localStorage.getItem('paper_cfg_symbol') || 'BTCUSDT';
      setSymbol(s);
      const raw = localStorage.getItem(`paper_cfg_${s}`);
      if (raw) {
        const saved = JSON.parse(raw);
        setCfg((prev) => ({ ...prev, ...saved }));
        // Fire-and-forget POST to hydrate backend
        setPaperConfig(s, saved).catch(() => {});
      } else {
        // Fetch current from backend
        getPaperConfig(s).then((res) => {
          const { atr_mult_stop, take_r_mult, max_hold_min, min_signal_score, risk_usd } = res || {};
          setCfg({ atr_mult_stop, take_r_mult, max_hold_min, min_signal_score, risk_usd });
        }).catch(() => {});
      }
    } catch {}
  }, []);

  const saveCfg = async () => {
    try {
      const res = await setPaperConfig(symbol, cfg);
      localStorage.setItem('paper_cfg_symbol', symbol);
      localStorage.setItem(`paper_cfg_${symbol}`, JSON.stringify(cfg));
      setCfg((prev) => ({ ...prev, ...res }));
      setSettingsOpen(false);
    } catch (e) {
      alert('Failed to save settings');
    }
  };

  // Proactive closure detection via /api/paper/trades
  useEffect(() => {
    let mounted = true;
    let timer;

    const pollTradesForClosure = async () => {
      if (!mounted) return;
      const entries = Array.from(openMapRef.current.values());
      if (entries.length === 0) return;
      // Group by symbol
      const bySymbol = new Map();
      for (const { item } of entries) {
        const sym = String(item.symbol || '').toUpperCase();
        if (!bySymbol.has(sym)) bySymbol.set(sym, []);
        bySymbol.get(sym).push(item);
      }

      try {
        const results = await Promise.all(Array.from(bySymbol.keys()).map((sym) => getPaperTrades(sym, 20)));
        const symbolList = Array.from(bySymbol.keys());
        const now = nowMs();
        let changed = false;
        for (let i = 0; i < results.length; i++) {
          const sym = symbolList[i];
          const trades = Array.isArray(results[i]) ? results[i] : [];
          for (const t of trades) {
            const tId = t?.id ?? t?.trade_id ?? t?.position_id ?? null;
            const tMemId = t?.mem_id ?? t?.memory_id ?? null;
            const isClosed = !!t?.closed;
            if (!isClosed) continue;
            for (const [key, rec] of openMapRef.current) {
              const it = rec.item;
              if (String((it.symbol || '').toUpperCase()) !== String(sym)) continue;
              if ((tId != null && String(it.id) === String(tId)) || (tMemId && String(it.id) === String(tMemId))) {
                openMapRef.current.delete(key);
                changed = true;
              }
            }
          }
        }
        if (changed) recomputeDisplay();
      } catch {}
    };

    timer = setInterval(pollTradesForClosure, 4000);
    return () => { mounted = false; if (timer) clearInterval(timer); };
  }, []);

  const positions = Array.isArray(data.open_positions) ? data.open_positions : [];
  const openUpnlClient = positions.reduce((sum, p) => sum + (Number(p?.upnl_estimate ?? 0) || 0), 0);
  const openUpnl = Number.isFinite(Number(data.open_upnl_usd)) && Number(data.open_upnl_usd) !== 0
    ? Number(data.open_upnl_usd)
    : openUpnlClient;
  const equityToday = Number.isFinite(Number(data.equity_today_usd)) && Number(data.equity_today_usd) !== 0
    ? Number(data.equity_today_usd)
    : Number(data.pnl_today ?? 0) + openUpnl;

  const onResetMetrics = async () => {
    try {
      await resetMetrics('now');
      const [state, summary] = await Promise.all([
        getMetricsState().catch(() => ({})),
        getPaperSummary().catch(() => ({})),
      ]);
      setData((prev) => ({ ...prev, ...(summary || {}), baseline_ts: state?.baseline_ts || prev.baseline_ts }));
    } catch (e) {
      // leave UI unchanged on error
    }
  };

  return (
    <>
    <div className="panel summary-panel">
      <div className="panel-header">Paper Summary</div>
      <div className="panel-body">
        {error ? (
          <div className="panel-error">{error}</div>
        ) : (
          <>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
              <div>
                <span style={{ fontSize: 12, color: '#2ecc71', border: '1px solid #2ecc71', padding: '2px 6px', borderRadius: 4 }}>
                  Auto exits: TP/SL x{num(cfg.take_r_mult / Math.max(cfg.atr_mult_stop, 1e-9), 2)} · {cfg.max_hold_min}m
                </span>
                {data.baseline_ts && (
                  <span style={{ marginLeft: 8, fontSize: 12, color: '#9aa4b2' }}>Baseline: {String(data.baseline_ts)}</span>
                )}
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <button onClick={onResetMetrics} style={{ fontSize: 12, padding: '4px 8px' }}>Reset</button>
                <button onClick={() => setSettingsOpen(true)} style={{ fontSize: 12, padding: '4px 8px' }}>Settings</button>
              </div>
            </div>
            <div className="summary-grid">
              <div className="summary-item">
                <div className="label">Equity Today (Realized + Unrealized)</div>
                <div className={`value ${equityToday >= 0 ? 'pos' : 'neg'}`}>${num(equityToday, 2)}</div>
                <div style={{ fontSize: 12, color: '#9aa4b2', marginTop: 2 }}>
                  Realized: ${num(data.pnl_today, 2)} | Unrealized: ${num(openUpnl, 2)}
                </div>
              </div>
              <div className="summary-item">
                <div className="label">Fees Today</div>
                <div className="value neg">${num(data.fees_today_usd ?? data.fees_today, 2)}</div>
              </div>
              <div className="summary-item">
                <div className="label">Funding Today</div>
                <div className="value neg">${num(data.funding_today_usd ?? data.funding_today, 2)}</div>
              </div>
              <div className="summary-item">
                <div className="label">Trades</div>
                <div className="value">{data.trades_closed ?? data.trades_today ?? 0}</div>
              </div>
              <div className="summary-item">
                <div className="label">Win Rate</div>
                <div className="value">{pct(data.win_rate_closed ?? data.win_rate_today)}</div>
              </div>
              <div className="summary-item">
                <div className="label">Avg R</div>
                <div className="value">{num(data.avg_R_today, 2)}</div>
              </div>
              <div className="summary-item">
                <div className="label">Max DD</div>
                <div className="value neg">${num(data.max_dd_today, 2)}</div>
              </div>
            </div>

            <div className="positions-title">Open Positions</div>
            <div className="table-wrap">
              <table className="positions-table">
                <thead>
                  <tr>
                    <th>Symbol</th>
                    <th>Side</th>
                    <th>Entry</th>
                    <th>Stop</th>
                    <th>Take</th>
                    <th>Risk $</th>
                    <th>Qty</th>
                    <th>uPnL</th>
                    <th>Src</th>
                  </tr>
                </thead>
                <tbody>
                  {positions.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="empty">No open positions</td>
                    </tr>
                  ) : (
                    positions.map((p) => (
                      <tr key={p.stableKey} style={{ opacity: p.stale ? 0.6 : 1 }}>
                        <td>{(p.symbol || '').toUpperCase()}</td>
                        <td className={((p.side || '').toLowerCase() === 'long') ? 'pos' : 'neg'}>{p.side}</td>
                        <td>{num(p.entry_price, 2)}</td>
                        <td>{p.stop_price != null ? num(p.stop_price, 2) : '—'}</td>
                        <td>{p.take_price != null ? num(p.take_price, 2) : '—'}</td>
                        <td>{p.risk_at_stop_usd != null ? num(p.risk_at_stop_usd, 2) : '—'}</td>
                        <td>{num(p.qty, 4)}</td>
                        <td className={(p.upnl_estimate ?? 0) >= 0 ? 'pos' : 'neg'}>{num(p.upnl_estimate, 2)}</td>
                        <td>
                          <span style={{ fontSize: 11, color: '#888', border: '1px solid #ccc', padding: '1px 4px', borderRadius: 3 }} title={`id: ${p.id}`}>
                            {p.source || 'unknown'}
                          </span>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>
      {settingsOpen && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.35)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 }}>
          <div style={{ background: '#111519', border: '1px solid #333', borderRadius: 8, padding: 16, width: 360 }}>
            <div style={{ fontSize: 16, marginBottom: 12 }}>Strategy Settings</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
              <label style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                <span style={{ fontSize: 12, color: '#9aa4b2' }}>Symbol</span>
                <select value={symbol} onChange={(e) => setSymbol(e.target.value)} style={{ padding: '6px 8px' }}>
                  <option>BTCUSDT</option>
                  <option>ETHUSDT</option>
                  <option>SOLUSDT</option>
                </select>
              </label>
              <label style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                <span style={{ fontSize: 12, color: '#9aa4b2' }}>Risk per trade (USD)</span>
                <input type="number" step="1" min="1" value={cfg.risk_usd}
                  onChange={(e) => setCfg({ ...cfg, risk_usd: Number(e.target.value) })}
                  style={{ padding: '6px 8px' }} />
              </label>
              <label style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                <span style={{ fontSize: 12, color: '#9aa4b2' }}>ATR stop multiplier</span>
                <input type="number" step="0.1" min="0.1" value={cfg.atr_mult_stop}
                  onChange={(e) => setCfg({ ...cfg, atr_mult_stop: Number(e.target.value) })}
                  style={{ padding: '6px 8px' }} />
              </label>
              <label style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                <span style={{ fontSize: 12, color: '#9aa4b2' }}>Take-profit R multiple</span>
                <input type="number" step="0.1" min="0.1" value={cfg.take_r_mult}
                  onChange={(e) => setCfg({ ...cfg, take_r_mult: Number(e.target.value) })}
                  style={{ padding: '6px 8px' }} />
              </label>
              <label style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                <span style={{ fontSize: 12, color: '#9aa4b2' }}>Max hold (minutes)</span>
                <input type="number" step="1" min="0" value={cfg.max_hold_min}
                  onChange={(e) => setCfg({ ...cfg, max_hold_min: Number(e.target.value) })}
                  style={{ padding: '6px 8px' }} />
              </label>
              <label style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                <span style={{ fontSize: 12, color: '#9aa4b2' }}>Min signal score</span>
                <input type="number" step="0.01" value={cfg.min_signal_score}
                  onChange={(e) => setCfg({ ...cfg, min_signal_score: Number(e.target.value) })}
                  style={{ padding: '6px 8px' }} />
              </label>
            </div>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 16 }}>
              <button onClick={() => setSettingsOpen(false)} style={{ padding: '6px 10px' }}>Cancel</button>
              <button onClick={saveCfg} style={{ padding: '6px 10px' }}>Save</button>
            </div>
          </div>
        </div>
      )}
    </div>
    {toast && (
      <div style={{ position: 'fixed', right: 16, bottom: 16, background: '#17212b', color: '#e6edf3', border: '1px solid #2b3a47', borderRadius: 6, padding: '8px 12px', zIndex: 1000, boxShadow: '0 2px 8px rgba(0,0,0,0.4)' }}>
        <span>{toast.text}</span>
        <button onClick={() => setToast(null)} style={{ marginLeft: 12, background: 'transparent', color: '#9aa4b2', border: 'none', cursor: 'pointer' }}>Dismiss</button>
      </div>
    )}
    </>
  );
};

export default SummaryPanel;


