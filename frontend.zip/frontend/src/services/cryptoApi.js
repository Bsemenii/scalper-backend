// Simple API service for fetching trades and order book
const API_BASE = "http://localhost:8000/api";

export async function fetchTrades(limit = 10) {
  const res = await fetch(`${API_BASE}/trades?limit=${limit}`);
  return res.json();
}

export async function fetchOrderBook() {
  const res = await fetch(`${API_BASE}/orderbook`);
  return res.json();
}

export async function fetchTicker() {
  const res = await fetch(`${API_BASE}/ticker`);
  return res.json();
}

// Trading control endpoints
export async function startTrading(symbol) {
  const params = new URLSearchParams({ symbol });
  const res = await fetch(`${API_BASE}/trading/start?${params.toString()}`, { method: 'POST' });
  return res.json();
}

export async function stopTrading(symbol) {
  const params = new URLSearchParams({ symbol });
  const res = await fetch(`${API_BASE}/trading/stop?${params.toString()}`, { method: 'POST' });
  return res.json();
}

export async function getTradingStatus(symbol) {
  const params = new URLSearchParams({ symbol });
  const res = await fetch(`${API_BASE}/trading/status?${params.toString()}`);
  return res.json();
}

// Paper trading APIs
export async function getPaperSummary() {
  const res = await fetch(`${API_BASE}/paper/summary`);
  return res.json();
}

export async function getMetricsState() {
  const res = await fetch(`${API_BASE}/paper/metrics_state`);
  return res.json();
}

export async function resetMetrics(baseline = 'now') {
  const res = await fetch(`${API_BASE}/paper/reset_metrics`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ baseline })
  });
  return res.json();
}

export async function getPaperTrades(symbol, limit = 20, since) {
  const sym = (symbol || '').toLowerCase();
  const params = new URLSearchParams({ symbol: sym, limit: String(limit) });
  if (since) params.set('since', since);
  const res = await fetch(`${API_BASE}/paper/trades?${params.toString()}`);
  return res.json();
}

export async function paperStart(symbol) {
  const res = await fetch(`${API_BASE}/paper/start`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ symbol })
  });
  return res.json();
}

export async function paperStop(symbol) {
  const res = await fetch(`${API_BASE}/paper/stop`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ symbol })
  });
  return res.json();
}

export async function getPaperStatus() {
  const res = await fetch(`${API_BASE}/paper/status`);
  return res.json();
}

// Open positions (fast path for instant feedback)
export async function getOpenPositions(symbol) {
  const params = symbol ? new URLSearchParams({ symbol: String(symbol).toLowerCase() }) : null;
  const url = params ? `${API_BASE}/paper/open_positions?${params.toString()}` : `${API_BASE}/paper/open_positions`;
  const res = await fetch(url);
  return res.json();
}

// Runtime heartbeat
export async function getRuntimeStatus() {
  const res = await fetch(`${API_BASE}/runtime/status`);
  return res.json();
}

// Backtest API
export async function runBacktest(params) {
  const body = {
    symbol: params.symbol || 'BTCUSDT',
    start: params.start,
    end: params.end,
    interval: params.interval || '1m',
    risk_usd: Number(params.risk_usd ?? 25),
    atr_mult_stop: Number(params.atr_mult_stop ?? 1.2),
    take_r_mult: Number(params.take_r_mult ?? 1.6),
    max_hold_min: Number(params.max_hold_min ?? 45),
    min_signal_score: Number(params.min_signal_score ?? 0.10),
    min_bars_warmup: Number(params.min_bars_warmup ?? 250),
    allow_flip_close_open: Boolean(params.allow_flip_close_open ?? false),
    debug: Boolean(params.debug ?? false),
  };
  const res = await fetch(`${API_BASE}/backtest/run`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(text || 'Backtest failed');
  }
  return res.json();
}

// Paper config per symbol
export async function getPaperConfig(symbol = 'BTCUSDT') {
  const params = new URLSearchParams({ symbol: String(symbol).toLowerCase() });
  const res = await fetch(`${API_BASE}/paper/config?${params.toString()}`);
  if (!res.ok) throw new Error('Failed to get config');
  return res.json();
}

export async function setPaperConfig(symbol, patch) {
  const params = new URLSearchParams({ symbol: String(symbol).toLowerCase() });
  const res = await fetch(`${API_BASE}/paper/config?${params.toString()}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(patch || {}),
  });
  if (!res.ok) throw new Error('Failed to set config');
  return res.json();
}