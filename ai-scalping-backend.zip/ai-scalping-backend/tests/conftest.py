import sys, pathlib
# добавить корень репозитория в sys.path, чтобы импортировался пакет "bot"
sys.path.append(str(pathlib.Path(__file__).resolve().parents[1]))
